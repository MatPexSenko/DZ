﻿using System;
using Game.Views;
using Modules.Planets;
using Modules.Utils;
using Sirenix.OdinInspector;
using UnityEngine;
using Zenject;

namespace Game.Presenters
{
    public class PlanetPresenter : IDisposable
    {
        [SerializeField]
        private PlanetView planetView;
        
        [ShowInInspector]
        private IPlanet planet;
        [SerializeField]
        private PlanetPopupPresentation planetPopup;
        
        private Countdown _countdown = new Countdown(2f);

        public PlanetPresenter(IPlanet planet, PlanetView planetView, PlanetPopupPresentation planetPopup)
        {
            this.planet = planet;
            this.planetView = planetView;
            this.planetPopup = planetPopup;
            
            planetView.Button.OnClick += OnClicked;
            planetView.Button.OnHold += OnLongClicked;
            planet.OnIncomeReady += ShowCoin;
            planet.OnUnlocked += UnlockPlanet;
            planet.OnUpgraded += Upgrade;
            
            UpdateState();
        }

        void UpdateState()
        {
            planetView.SetPrice(planet.Price.ToString());
            planetView.SetPlanetImage(planet.GetIcon(planet.IsUnlocked));
            planetView.SetEnableLockImage(!planet.IsUnlocked);
            planetView.SetEnableCoinImage(planet.IsUnlocked);
        }

        private void UnlockPlanet()
        {
            planetView.SetEnableLockImage(false);
            planetView.SetPlanetImage(planet.GetIcon(planet.IsUnlocked));
            planetView.SetPrice(planet.Price.ToString());
        }

        private void ShowCoin(bool obj)
        {
            planetView.SetEnableCoinImage(obj);
            Debug.Log(obj);
        }

        public void Dispose()
        {
            planetView.Button.OnClick -= OnClicked;
            planetView.Button.OnHold -= OnLongClicked;
        }
        
        private void OnClicked()
        {
            if (planet.IsUnlocked && planet.IsIncomeReady)
            {
                planetView.StartCoinAnimation(OnReachTarget: () => planet.GatherIncome());
                Debug.Log("Click");
                return;
            }
            planet.Unlock();
        }

        private void OnLongClicked()
        {
            planetPopup.Show(new PlanetPopupPresentation.Args(this.planet));
        }

        private void Upgrade(int Level)
        {
            planetView.SetPrice(planet.Price.ToString());
            if (planet.IsMaxLevel)
            {
                planetView.SetPrice("MAX");
            }
        }
        
        public class Factory : PlaceholderFactory<Planet, PlanetView, PlanetPresenter>
        {
        }
    }
}