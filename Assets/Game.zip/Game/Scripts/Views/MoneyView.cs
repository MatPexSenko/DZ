﻿using R3;
using Sirenix.OdinInspector;
using TMPro;
using UnityEngine;
using Zenject;
using Game.Presenters;

namespace Game.Views
{
    public sealed class MoneyView : MonoBehaviour
    {
        [SerializeField] 
        private TMP_Text _coinCount;
        
        [ShowInInspector]private MoneyPresentation _presentation;
        private readonly CompositeDisposable _disposables = new();
        
        private WaitForSeconds _waitForSeconds;
        
        [Inject]
        public void Construct(MoneyPresentation presentation)
        {
            _presentation = presentation;
            Debug.Log($"Money Presentation {_presentation}");
        }
        private void OnEnable()
        {
            _presentation.Money
                .Subscribe(x => SetCoinCount(x))
                .AddTo(_disposables);
        }

        private void OnDisable()
        {
            _disposables.Dispose();
        }
        public void SetCoinCount(string coinCount)
        {
            Debug.Log($"Money Presentation {_presentation}");
            _coinCount.text = coinCount;
        }
    }
}