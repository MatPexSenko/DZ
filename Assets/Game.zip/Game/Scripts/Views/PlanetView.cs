﻿using System;
using Modules.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Game.Views
{
    public class PlanetView : MonoBehaviour
    {
        public SmartButton Button => button;
        [SerializeField] private SmartButton button;

        [SerializeField] private TMP_Text _price;

        [SerializeField] private Image _lock;

        [SerializeField] private Image _coin;

        [SerializeField] private Image _planetImage;

        [SerializeField] private UIFlyToTarget _flyToTarget;

        public void SetPlanetImage(Sprite image)
        {
            _planetImage.sprite = image;
        }

        public void SetPrice(string price)
        {
            _price.text = price;
        }
        
        public void SetEnableCoinImage(bool x) => _coin.enabled = x;
        
        public void SetEnableLockImage(bool x) => _lock.enabled = x;

        public void StartCoinAnimation(Action OnReachTarget = null)
        {
            _flyToTarget.Fly(_coin.gameObject.GetComponent<RectTransform>(), OnReachTarget);
        }
    }
}