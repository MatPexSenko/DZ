using Game.Presenters;
using Modules.Planets;
using Zenject;

namespace Game.Views
{
    public sealed class ViewsInstaller : MonoInstaller
    {
        public override void InstallBindings()
        {
            this.Container.BindFactory<Planet, PlanetView, PlanetPresenter,PlanetPresenter.Factory>();
            this.Container.BindFactory<IPlanet,IncomeView, IncomePresentation ,IncomePresentation.Factory>();
        }
    }
}