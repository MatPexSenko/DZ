﻿using System.Collections.Generic;
using Game.Presenters;
using Game.Views;
using Modules.Planets;
using UnityEngine;
using Zenject;

namespace Game
{
    public class StartPoint : MonoBehaviour
    {
        [SerializeField]
        private List<PlanetView> planets;
        [SerializeField]
        private List<IncomeView> incomeView;
        [SerializeField, Inject]
        private List<IncomePresentation> incomePresentation;
        [SerializeField, Inject]
        private List<Planet> iplanets;
        [SerializeField, Inject]
        private PlanetPresenter.Factory factory;
        
        private void Awake()
        {
            var count = Mathf.Min(planets.Count, iplanets.Count);
        
            for (int i = 0; i < count; i++)
            {
                var planetView = planets[i];
                var iplanet = iplanets[i];
                
                factory.Create(iplanet, planetView);
            }
            
            count = Mathf.Min(incomePresentation.Count, incomeView.Count);
            for (int i = 0; i < count; i++)
            {
                IncomeView view = incomeView[i];
                var presentation = incomePresentation[i];
                view.Construct(presentation);
            }
        }
    }
}